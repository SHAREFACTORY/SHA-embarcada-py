# node-red-contrib-df1
A Node-RED Node to communicate with Allen Bradley PLCs over Serial Port

This node was created as part of the [ST-One](https://st-one.io) project.
